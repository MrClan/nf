module.exports = () => ({});
